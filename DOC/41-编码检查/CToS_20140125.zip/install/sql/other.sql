ALTER TABLE `tp_wxuser` ADD `phone` TEXT NOT NULL ,
ADD `smsstatus` TEXT NOT NULL ,
ADD `smsuser` TEXT NOT NULL ,
ADD `smspassword` TEXT NOT NULL ,
ADD `email` TEXT NOT NULL ,
ADD `emailstatus` TEXT NOT NULL ,
ADD `emailuser` TEXT NOT NULL ,
ADD `emailpassword` TEXT NOT NULL ,
ADD  `yunuser` TEXT NOT NULL ,
ADD  `yunpassword` TEXT NOT NULL ,
ADD  `yunname` TEXT NOT NULL ,
ADD  `yundomain` TEXT NOT NULL，
ADD  `yunstatus` TEXT NOT NULL;