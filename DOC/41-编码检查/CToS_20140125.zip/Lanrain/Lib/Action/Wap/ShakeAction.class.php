<?php
class ShakeAction extends BaseAction{
     public function index(){
     $this->display();
     }
}
?>