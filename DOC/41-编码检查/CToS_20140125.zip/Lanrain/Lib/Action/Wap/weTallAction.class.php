<?php
  class weTallAction extends BaseAction{
    public function index(){
     $this->display();
    }
  }
?>