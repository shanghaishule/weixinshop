<?php 
return array (
  'BASIC_THEME' => 'default',
  'DEFAULT_THEME' => 'default',
);