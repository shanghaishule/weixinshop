<?php
return array(
  'name' => '首页会员下方',
  'option' => true,
  'allow_type' => array('text'),
);