<?php
return array(
  'name' => '专辑焦点图',
  'option' => true,
  'allow_type' => array('image'),
);