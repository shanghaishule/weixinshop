<?php
return array(
  'name' => '关注我们',
  'option' => true,
  'allow_type' => array('text'),
);