<?php
return array(
  'name' => '矩形横幅',
  'option' => true,
  'allow_type' => array('text','image','code','flash'),
);