<?php

class item_imgModel extends Model
{
    protected $_auto = array (array('add_time','time',1,'function'));
}