<?php

return array(
    'wellcome_back' => '欢迎回来',
    'go' => '去',
    'see_friends_feed' => '看看好友动态',
    'register_now' => '立即注册',
    'wonderful_album' => '精彩专辑',
);
