<div class="footc" id="">
	<div class="footcT">网站信息<span><a href="javascript:void()" id="divYes">打开</a></span></div>
    <div class="footcC" style="display:none">WxWall</div>
</div>
<!-- End Notifications -->
    <div id="footer"> <small>
      <!-- Remove this notice or replace it with whatever you want -->
      &#169; Copyright 2013 CoolWB | Powered by <a href="http://weixincat.com">weixincat.COM</a> | <a href="#">Top</a> </small>
 </div>
    <!-- End #footer -->
  </div>
  <!-- End #main-content -->
</div>