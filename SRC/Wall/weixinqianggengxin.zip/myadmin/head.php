<div id="body-wrapper">
  <!-- Wrapper for the radial gradient background -->
  <div id="sidebar">
    <div id="sidebar-wrapper">
      <!--网站信息-->
      <!-- Sidebar with logo and menu -->
      <h1 id="sidebar-title"><a href="#">Simpla Admin</a></h1>
      <!-- Logo (221px wide) -->
      <a href="#"><img id="logo" src="themes/images/nlogo.png" weight=10px height=45px alt="微信墙" /></a>
      <!-- Sidebar Profile links -->
      <div id="profile-links"> 微信墙<br />
        <br />
      <a href="http://coolwb.com/5602.html" title="客服中心" target="_blank">在线客服</a>&nbsp|&nbsp<a href="main.php" title="后台">后台首页</a>&nbsp|&nbsp<a href="logout.php" title="退出">退出</a></div>
      <ul id="main-nav">
        <!-- Accordion Menu -->
        <li> <a href="#" class="nav-top-item" id="up">
          <!-- Add the class "current" to current menu item -->
          上墙 </a>
          <ul>
            <li><a href="shenhe.php"  id="shenhe">审核上墙</a></li>
            <li><a href="zhijie.php"  id="shenhe">直接上墙</a></li>
          </ul>
        </li>
		 <li> <a href="#" class="nav-top-item" id="up">
          <!-- Add the class "current" to current menu item -->
          投票 </a>
          <ul>
            <li><a href="toupiao.php"  id="shenhe">投票管理</a></li>
          </ul>
         <li> <a href="#" class="nav-top-item" id="up">
          <!-- Add the class "current" to current menu item -->
          抽奖 </a>
          <ul>
            <li><a href="choujiang.php"  id="shenhe">抽奖</a></li>
          </ul>
        </li>
        
        
</ul>
      <!-- End #main-nav -->
     
      <!-- End #messages -->
    </div>
  </div>
  <!-- End #sidebar -->
  <div id="main-content">
    
    <noscript>
    <div class="notification error png_bg">
      <div> 您当前使用的浏览器禁止了网页中的JavaScript代码，这些代码将为您呈现更好的用户体验，请您 <a href="http://www.google.com/support/bin/answer.py?answer=23852" title="点击升级浏览器">升级浏览器</a> 以便JavaScript能在网页中正常运行.
        
      </div>
    </div>
    </noscript>
    <!-- Page Head -->
    <h2>审核</h2>
    <p id="page-intro">微信墙上墙功能审核后台</p>
    
    <ul class="shortcut-buttons-set">
      <li><a class="shortcut-button" href="shenhe.php"><span> <img src="themes/images/icons/pencil_48.png" alt="icon" /><br />
        上墙审核管理 </span></a></li>
      <li><a class="shortcut-button" href="toupiao.php"><span> <img src="themes/images/icons/clock_48.png" alt="icon" /><br />
        投票管理 </span></a></li>
 </ul>
    <!-- End .shortcut-buttons-set -->
    <div class="clear"></div>
    <!-- End .clear -->