<?php

	/***配置数据库名称***/
	define("MYSQLNAME", "uPTamtPRhLVrIHJvazsn");//数据库名称
	


	/***粉丝采集微信公众平台密码配置***/
define("USER", "1450070909@qq.com");//公众平台账号 不能带空格
	define("PASS", "1303476572");//公众平台密码  不能带空格



  

   define("UR", "http://1.wstreet123.duapp.com");////注意com后面不能带有斜线 上传后的地址

	//DEST_URL地址必须是云存储（BCS）中的地址
	define("OFFLINEDOWNLOAD_DEST_URL", "bcs.duapp.com");
