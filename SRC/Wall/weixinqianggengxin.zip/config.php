<?php
@header("Content-type: text/html; charset=utf-8");
 
define("TOKEN", "weixin"); //配置API
$url='http://1.wstreet123.duapp.com/1.php';//这个填写你的1.php这个文件的地址
$weixin_name='安宁信息港';//这里可以配置你的微信公众账号名字，你也可以改下面的源码
$weixin_wxq='http://1.wstreet123.duapp.com/wall/';//这里填写你的微信墙的地址
$huati='@';//话题内容 如：#我爱你#
$wxname='1450070909@qq.com'; 
$pwd="1303476572";
$siurl='http://http://1.wstreet123.duapp.com/duapp.com';//注意com后面不能带有斜线 上传后的地址
		/*链接数据库*/
	   $dbname = 'uPTamtPRhLVrIHJvazsn';//这里填写你BAE数据库的名称
 
       /*从环境变量里取出数据库连接需要的参数*/
       $host = getenv('HTTP_BAE_ENV_ADDR_SQL_IP');
       $port = getenv('HTTP_BAE_ENV_ADDR_SQL_PORT');
       $user = getenv('HTTP_BAE_ENV_AK');
       $pwd = getenv('HTTP_BAE_ENV_SK');
 
       /*接着调用mysql_connect()连接服务器*/
        $link = @mysql_connect("{$host}:{$port}",$user,$pwd,true);
       if(!$link) {
                   die("Connect Server Failed: " . mysql_error($link));
                  }
       /*连接成功后立即调用mysql_select_db()选中需要连接的数据库*/
       if(!mysql_select_db($dbname,$link)) {
                   die("Select Database Failed: " . mysql_error($link));
                  }
		mysql_query("SET NAMES UTF8");
//以上连接数据库
?>